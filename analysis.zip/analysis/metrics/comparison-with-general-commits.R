specific<-read.table("beforeAfter.csv",sep=",",header=TRUE)
general<-read.table("beforeAfterGeneralCommits.csv",sep=",",header=TRUE)

#subsets by measure
cohesion_specific <- specific[which(specific["measure"] == 'cohesion'),]
coupling_specific <- specific[which(specific["measure"] == 'coupling'),]
complexity_specific <- specific[which(specific["measure"] == 'complexity'),]
readability_specific <- specific[which(specific["measure"] == 'readability'),]

cohesion_general <- general[which(general["measure"] == 'cohesion'),]
coupling_general <- general[which(general["measure"] == 'coupling'),]
complexity_general <- general[which(general["measure"] == 'complexity'),]
readability_general <- general[which(general["measure"] == 'readability'),]

#subsets by metric
lcom_specific <- cohesion_specific[which(cohesion_specific["metric_name"] == 'LCOM'),]
c3_specific <- cohesion_specific[which(cohesion_specific["metric_name"] == 'C3'),]
wmc_specific <- complexity_specific[which(complexity_specific["metric_name"] == 'WMC'),]
cbo_specific <- coupling_specific[which(coupling_specific["metric_name"] == 'CBO'),]
rfc_specific <- coupling_specific[which(coupling_specific["metric_name"] == 'RFC'),]
buse_specific <- readability_specific[which(readability_specific["metric_name"] == 'readability-bw'),]
scalabrino_specific <- readability_specific[which(readability_specific["metric_name"] == 'readability-s'),]

#subsets by metric
lcom_general <- cohesion_general[which(cohesion_general["metric_name"] == 'LCOM'),]
c3_general <- cohesion_general[which(cohesion_general["metric_name"] == 'C3'),]
wmc_general <- complexity_general[which(complexity_general["metric_name"] == 'WMC'),]
cbo_general <- coupling_general[which(coupling_general["metric_name"] == 'CBO'),]
rfc_general <- coupling_general[which(coupling_general["metric_name"] == 'RFC'),]
buse_general <- readability_general[which(readability_general["metric_name"] == 'readability-bw'),]
scalabrino_general <- readability_general[which(readability_general["metric_name"] == 'readability-s'),]


#STATISTICAL TESTS (orddom library is needed)
#Statistical analysis
#Needed to compute the cliffdelta
if (!require(orddom))
{
  install.packages("orddom")
  library(orddom)
}

################Function to run statistical analysis################
runStatAnalysis <- function(dist1, dist2){
result<-c()
result[1]<-wilcox.test(dist1,dist2,alternative="two.side",paired=FALSE)$p.value

t1=as.matrix(dist1)
colnames(t1)<-c("t1")
t2=as.matrix(dist2)
colnames(t2)<-c("t2")
o<-orddom(t1,t2)
result[2]<-o[13,1]
return(result)
}
################END Function to run statistical analysis################
names<-c()
pval<-c()
esize<-c()

names<-c(names,"LCOM")
result<-runStatAnalysis(lcom_specific$diff,lcom_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"C3")
result<-runStatAnalysis(c3_specific$diff,c3_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"CBO")
result<-runStatAnalysis(cbo_specific$diff,cbo_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"RFC")
result<-runStatAnalysis(rfc_specific$diff,rfc_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"WMC")
result<-runStatAnalysis(wmc_specific$diff,wmc_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"BUSE")
result<-runStatAnalysis(buse_specific$diff,buse_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

names<-c(names,"SCALABRINO")
result<-runStatAnalysis(scalabrino_specific$diff,scalabrino_general$diff)
pval<-c(pval,result[1])
esize<-c(esize,result[2])

adj<-p.adjust(pval,method="holm")

for(i in 1:(length(adj))){
	message(names[i], ": p-value=", adj[i], " | d=", esize[i])
}

